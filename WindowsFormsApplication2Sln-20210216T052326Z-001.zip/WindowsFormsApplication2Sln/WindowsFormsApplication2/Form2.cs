﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Table1 : Form
    {
        //Totalbutton
        private void button3_Click(object sender, EventArgs e)
        {
            double fer, bur, piz, san, dess, tecf, fer2, bur2, piz2, san2, dess2, tecf2, bur3, piz3, san3, dess3, tecf3, tecf4, tecf5, piz4;
            double tax;
            tax = 0.45;

            fer = 100; fer2 = 50; bur = 120; bur2 = 150; bur3 = 200; piz = 150; piz2 = 200; piz3 = 250; piz4 = 190; san = 180; san2 = 60; san3 = 70; dess = 40; dess2 = 120; dess3 = 150; tecf = 25;
            tecf2 = 15; tecf3 = 40; tecf4 = 60; tecf5 = 70; 
            

            double frice = Convert.ToDouble(numeric1.Value);
            double frice2 = Convert.ToDouble(numeri2.Value);

            double burger = Convert.ToDouble(numeric2.Value);
            double burger2 = Convert.ToDouble(numeri3.Value);
            double burger3 = Convert.ToDouble(numeri4.Value);

            double pizza = Convert.ToDouble(numeric3.Value);
            double pizza2 = Convert.ToDouble(numeri6.Value);
            double pizza3 = Convert.ToDouble(numeri7.Value);
            double pizza4 = Convert.ToDouble(numeric8.Value);

            double sand = Convert.ToDouble(numeric4.Value);
            double sand2 = Convert.ToDouble(numeri5.Value);
            double sand3 = Convert.ToDouble(numeric9.Value);

            double dessert = Convert.ToDouble(numeric5.Value);
            double dessert2 = Convert.ToDouble(numeric0.Value);
            double dessert3 = Convert.ToDouble(numeric11.Value);

            double teacof = Convert.ToDouble(numeric6.Value);
            double teacof2 = Convert.ToDouble(numeric7.Value);
            double teacof3 = Convert.ToDouble(numeric14.Value);
            double teacof4 = Convert.ToDouble(numeri12.Value);
            double teacof5 = Convert.ToDouble(numeric13.Value);

           


            amount OR = new amount(frice, burger, pizza, sand, dessert, teacof, frice2, burger2, pizza2, sand2, dessert2, teacof2, burger3, pizza3, sand3, dessert3, teacof3, teacof4, teacof5, pizza4);

            double foodCosts = ((frice * fer) + (frice2 * fer2) + (burger * bur) + (burger2 * bur2) + (burger3 * bur3) + (pizza * piz) + (pizza2 * piz2) + (pizza3 * piz3) + (pizza4 * piz4) + (sand * san) + (sand2 * san2) + (sand3 * san3) +
                (dessert * dess) +(dessert2 * dess2) +  (dessert3 * dess3) );

            textBox2.Text = Convert.ToString(foodCosts);

            double drinksCost1 =(teacof * tecf)  + (teacof2 * tecf2) + (teacof3 * tecf3) + (teacof4 * tecf4) + (teacof5 * tecf5);

            textBox1.Text = Convert.ToString(drinksCost1);


         
            textBox3.Text = Convert.ToString(((foodCosts + drinksCost1) * tax) / 100);
            double totalAftTax = Convert.ToDouble(textBox3.Text);
            textBox5.Text = Convert.ToString(foodCosts + drinksCost1 + totalAftTax);
            textBox1.Text = String.Format("{0}", (drinksCost1));
            textBox2.Text = String.Format("{0}", (foodCosts));
            textBox4.Text = String.Format("{0}", (foodCosts + drinksCost1));
            textBox3.Text = String.Format("{0}", totalAftTax);
            textBox5.Text = String.Format("{0}", (foodCosts + drinksCost1 + totalAftTax));
        }

        //Reset button
        private void Initialize()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = "0";

            labe1.Text = labe2.Text = label3.Text = labe4.Text = labe5.Text = labe6.Text = labe7.Text = label4.Text = label5.Text = " ";
            label9.Text = label19.Text = label22.Text = label7.Text = label10.Text = label20.Text = label23.Text = label25.Text = label12.Text = label26.Text = label27.Text = " ";

            numeric1.Value = numeri2.Value = numeric2.Value = numeric3.Value = numeri4.Value = 0;
            numeri6.Value = numeri7.Value = numeric8.Value = numeric4.Value = numeri5.Value = 0;
            numeric9.Value = numeri5.Value = numeric0.Value = numeric11.Value = numeric6.Value = numeric7.Value = numeric14.Value = numeri12.Value = numeric13.Value = 0;

            chefries.Checked = checkBox1.Checked = checkBox2.Checked = checkBox3.Checked = chepizza.Checked = checkBox4.Checked = checkBox5.Checked = checkBox6.Checked = false;
            checkBox7.Checked = checkBox8.Checked = checkBox9.Checked = checkBox10.Checked = checkBox13.Checked = chesand.Checked = chedes.Checked = chedr.Checked = checkBox14.Checked = false;

            print.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Initialize();
        }
       

   
       
           //printbox


        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox5.Text != "0")
            {
                print.Enabled = true;
            }
            else
            {
                print.Enabled = false;
                print.Clear();
            }

            print.Clear();

            print.AppendText("\t\t" + "Hungry Buddy " + Environment.NewLine);
            print.AppendText("-----------------------------------------------------" + Environment.NewLine);
            print.AppendText("                            Quantity                  Price" + Environment.NewLine);

            print.AppendText("Fried Chicken  \t\t" + numeric1.Value + "\t\t" + labe1.Text + Environment.NewLine);
            print.AppendText("France Fry      \t\t" + numeri2.Value + "\t\t" + label4.Text + Environment.NewLine);
            print.AppendText("Beef Burger     \t\t" + numeric2.Value + "\t\t" + labe2.Text + Environment.NewLine);
            print.AppendText("Chicken Burger  \t\t" + numeri3.Value + "\t\t" + label5.Text + Environment.NewLine);
            print.AppendText("Cheese Burger   \t\t" + numeri4.Value + "\t\t" + label7.Text + Environment.NewLine);
            print.AppendText("Cheese Pizza    \t\t" + numeric3.Value + "\t\t" + label3.Text + Environment.NewLine);
            print.AppendText("Beef Pizza     \t\t" + numeri6.Value + "\t\t" + label9.Text + Environment.NewLine);
            print.AppendText("Chicken Pizza   \t\t" + numeri7.Value + "\t\t" + label10.Text + Environment.NewLine);
            print.AppendText("Plane Pizza     \t\t" + numeric8.Value + "\t\t" + label12.Text + Environment.NewLine);
            print.AppendText("Sub Sandwich    \t\t" + numeric4.Value + "\t\t" + labe4.Text + Environment.NewLine);
            print.AppendText("Smoki Sandwich  \t\t" + numeri5.Value + "\t\t" + label19.Text + Environment.NewLine);
            print.AppendText("Cheese Sandwich \t\t" + numeric9.Value + "\t\t" + label20.Text + Environment.NewLine);
            print.AppendText("Misty           \t\t\t" + numeric5.Value + "\t\t" + labe5.Text + Environment.NewLine);
            print.AppendText("Chocolate Cake  \t\t" + numeric0.Value + "\t\t" + label22.Text + Environment.NewLine);
            print.AppendText("Ice Cream       \t\t" + numeric11.Value + "\t\t" + label23.Text + Environment.NewLine);
            print.AppendText("Coca Cola       \t\t" + numeric6.Value + "\t\t" + labe6.Text + Environment.NewLine);
            print.AppendText("Tea             \t\t\t" + numeric7.Value + "\t\t" + labe7.Text + Environment.NewLine);
            print.AppendText("Coffee          \t\t\t" + numeric14.Value + "\t\t" + label25.Text + Environment.NewLine);
            print.AppendText("Cold Coffee     \t\t" + numeri12.Value + "\t\t" + label26.Text + Environment.NewLine);
            print.AppendText("Mlik Shak       \t\t" + numeric13.Value + "\t\t" + label27.Text + Environment.NewLine);

            print.AppendText("---------------------------------------------------" + Environment.NewLine);
            print.AppendText("Vat         \t\t\t\t\t  " + textBox3.Text + Environment.NewLine);
            print.AppendText("Sub Total    \t \t\t\t\t   " + textBox4.Text + Environment.NewLine);
            print.AppendText("Total Co       \t\t\t\t\t   " + textBox5.Text + Environment.NewLine);
            print.AppendText("-----------------------------------------------------" + Environment.NewLine);
           
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(print.Text, new Font("Microsoft YaHei UI", 14, FontStyle.Regular), Brushes.Black, 120, 120);
        }

        private void printToolStripButton_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            print.Clear();
        }

        private void cutToolStripButton_Click(object sender, EventArgs e)
        {
            print.Cut();
        }

        private void copyToolStripButton_Click(object sender, EventArgs e)
        {
            print.Copy();
        }

        private void pasteToolStripButton_Click(object sender, EventArgs e)
        {
            print.Paste();
        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
          
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "Text Files (*.txt)|*.txt|All files (*.*)|*.*";

            if (openFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                print.LoadFile(openFile.FileName, RichTextBoxStreamType.PlainText);
            }
        }

        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            
            SaveFileDialog saveFile = new SaveFileDialog();

            saveFile.FileName = "Notepad Text";
            saveFile.Filter = "Text Files (*.txt)|*.txt|All files (*.*)|*.*";


            if (saveFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(saveFile.FileName))
                    sw.WriteLine(print.Text);
            }
        }

        //Exit

        private void button6_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Thank you for order .. Enjoy the food.");
            Application.Exit();
        }




        public Table1()
        {
            InitializeComponent();
             
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = "0";

            labe1.Text = labe2.Text = label3.Text = labe4.Text = labe5.Text = labe6.Text = labe7.Text = label4.Text = label5.Text = " ";
            label9.Text = label19.Text = label22.Text = label7.Text = label10.Text = label20.Text = label23.Text = label25.Text = label12.Text = label26.Text = label27.Text = " ";

            numeric1.Value = numeri2.Value = numeric2.Value = numeric3.Value = numeri4.Value = 0;
            numeri6.Value = numeri7.Value = numeric8.Value = numeric4.Value = numeri5.Value = 0;
            numeric9.Value = numeri5.Value = numeric0.Value = numeric11.Value = numeric6.Value = numeric7.Value = numeric14.Value = numeri12.Value = numeric13.Value = 0;

            chefries.Checked = checkBox1.Checked = checkBox2.Checked = checkBox3.Checked = chepizza.Checked = checkBox4.Checked = checkBox5.Checked = checkBox6.Checked = false;
            checkBox7.Checked = checkBox8.Checked = checkBox9.Checked = checkBox10.Checked = checkBox13.Checked = chesand.Checked = chedes.Checked = chedr.Checked = checkBox14.Checked = false;

            print.Clear();

           
        }


        private void chefries_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric1.Value;
            int total = quantity * 100;
            if (chefries.Checked == true)
            {
                numeric1.Enabled = true;
            }
            else
            {
                numeric1.Enabled = false;

            }

            labe1.Text = total.ToString();

        }


        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeri2.Value;
            int total2 = quantity * 50;

            if (checkBox1.Checked == true)
            {
                numeri2.Enabled = true;
            }
            else
            {
                numeri2.Enabled = false;

            }

            label4.Text = total2.ToString();
        }


        private void cheburger_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric2.Value;
            int total3 = quantity * 120;
            if (cheburger.Checked == true)
            {
                numeric2.Enabled = true;
            }
            else
            {
                numeric2.Enabled = false;

            }

            labe2.Text = total3.ToString();
        }



        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeri3.Value;
            int total4 = quantity * 150;
            if (checkBox2.Checked == true)
            {
                numeri3.Enabled = true;
            }
            else
            {
                numeri3.Enabled = false;

            }

            label5.Text = total4.ToString();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeri4.Value;
            int total5 = quantity * 200;
            if (checkBox3.Checked == true)
            {
                numeri4.Enabled = true;
            }
            else
            {
                numeri4.Enabled = false;

            }

            label7.Text = total5.ToString();
        }

        private void chepizza_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric3.Value;
            int total6 = quantity * 150;
            if (chepizza.Checked == true)
            {
                numeric3.Enabled = true;
            }
            else
            {
                numeric3.Enabled = false;

            }

            label3.Text = total6.ToString();

        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeri6.Value;
            int total7 = quantity * 200;
            if (checkBox5.Checked == true)
            {
                numeri6.Enabled = true;
            }
            else
            {
                numeri6.Enabled = false;

            }

            label9.Text = total7.ToString();
        }


        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeri7.Value;
            int total8 = quantity * 250;
            if (checkBox5.Checked == true)
            {
                numeri7.Enabled = true;
            }
            else
            {
                numeri7.Enabled = false;

            }

            label10.Text = total8.ToString();

        }


        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric8.Value;
            int total9 = quantity * 190;
            if (checkBox5.Checked == true)
            {
                numeric8.Enabled = true;
            }
            else
            {
                numeric8.Enabled = false;

            }

            label12.Text = total9.ToString();

        }

        private void chesand_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric4.Value;
            int total10 = quantity * 180;
            if (chesand.Checked == true)
            {
                numeric4.Enabled = true;
            }
            else
            {
                numeric4.Enabled = false;

            }

            labe4.Text = total10.ToString();

        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeri5.Value;
            int total11 = quantity * 60;
            if (checkBox8.Checked == true)
            {
                numeri5.Enabled = true;
            }
            else
            {
                numeri5.Enabled = false;

            }

            label19.Text = total11.ToString();
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric9.Value;
            int total12 = quantity * 70;
            if (checkBox9.Checked == true)
            {
                numeric9.Enabled = true;
            }
            else
            {
                numeric9.Enabled = false;

            }

            label20.Text = total12.ToString();

        }


        private void chedes_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric5.Value;
            int total13 = quantity * 40;
            if (chedes.Checked == true)
            {
                numeric5.Enabled = true;
            }
            else
            {
                numeric5.Enabled = false;

            }

            labe5.Text = total13.ToString();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric0.Value;
            int total14 = quantity * 120;
            if (checkBox4.Checked == true)
            {
                numeric0.Enabled = true;
            }
            else
            {
                numeric0.Enabled = false;

            }

            label22.Text = total14.ToString();

        }
        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric11.Value;
            int total15 = quantity * 120;
            if (checkBox10.Checked == true)
            {
                numeric11.Enabled = true;
            }
            else
            {
                numeric11.Enabled = false;

            }

            label23.Text = total15.ToString();

        }


        private void chedr_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric6.Value;
            int total16 = quantity * 25;

            if (chedr.Checked == true)
            {
                numeric6.Enabled = true;
            }
            else
            {
                numeric6.Enabled = false;

            }

            labe6.Text = total16.ToString();
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            int quantity17 = (int)numeric7.Value;
            int total17 = quantity17 * 15;

            if (checkBox11.Checked == true)
            {
                numeric7.Enabled = true;
            }
            else
            {
                numeric7.Enabled = false;

            }

            labe7.Text = total17.ToString();
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            int quantity18 = (int)numeric14.Value;
            int total18 = quantity18 * 40;
            if (checkBox12.Checked == true)
            {
                numeric14.Enabled = true;
            }
            else
            {
                numeric14.Enabled = false;

            }

            label25.Text = total18.ToString();
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            int quantity19 = (int)numeri12.Value;
            int total19 = quantity19 * 60;

            if (checkBox13.Checked == true)
            {
                numeri12.Enabled = true;
            }
            else
            {
                numeri12.Enabled = false;

            }

            label26.Text = total19.ToString();
        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            int quantity = (int)numeric13.Value;
            int total20 = quantity * 70;

            if (checkBox14.Checked == true)
            {
                numeric13.Enabled = true;
            }
            else
            {
                numeric13.Enabled = false;

            }

            label27.Text = total20.ToString();
        }

        private void groupBox2_Enter(object sender, EventArgs e) { }
        private void printPreviewDialog1_Load(object sender, EventArgs e){}
        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e) { }
        private void numeric1_ValueChanged(object sender, EventArgs e) { }
        private void numeric2_ValueChanged(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e){}
        private void numeric5_ValueChanged(object sender, EventArgs e) {}
        private void numeric6_ValueChanged(object sender, EventArgs e){}
        private void numeric7_ValueChanged(object sender, EventArgs e) { }
        private void toolStripButton1_Click(object sender, EventArgs e) { }
        private void panel1_Paint(object sender, PaintEventArgs e){}
        private void label18_Click(object sender, EventArgs e){}
        private void textBox3_TextChanged(object sender, EventArgs e){}
        private void groupBox6_Enter(object sender, EventArgs e){}
        private void label8_Click(object sender, EventArgs e){}     
        private void numericUpDown1_ValueChanged(object sender, EventArgs e){}
        private void numericUpDown3_ValueChanged(object sender, EventArgs e){}      
        private void groupBox5_Enter(object sender, EventArgs e){}
        private void numericUpDown2_ValueChanged(object sender, EventArgs e) { }
        private void groupBox1_Enter(object sender, EventArgs e) { }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void groupBox10_Enter(object sender, EventArgs e)
        {

        }

       

        
       
     
       
        
        }
    
}
