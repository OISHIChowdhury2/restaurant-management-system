﻿namespace WindowsFormsApplication2
{
    partial class Table1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Table1));
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.print = new System.Windows.Forms.RichTextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.savetoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.cutetoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.pastetoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.printtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.chedr = new System.Windows.Forms.CheckBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.numeric14 = new System.Windows.Forms.NumericUpDown();
            this.numeric13 = new System.Windows.Forms.NumericUpDown();
            this.numeri12 = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.labe7 = new System.Windows.Forms.Label();
            this.numeric7 = new System.Windows.Forms.NumericUpDown();
            this.labe6 = new System.Windows.Forms.Label();
            this.numeric6 = new System.Windows.Forms.NumericUpDown();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.chefries = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.numeri2 = new System.Windows.Forms.NumericUpDown();
            this.numeric1 = new System.Windows.Forms.NumericUpDown();
            this.labe1 = new System.Windows.Forms.Label();
            this.numeric2 = new System.Windows.Forms.NumericUpDown();
            this.numeric3 = new System.Windows.Forms.NumericUpDown();
            this.numeric4 = new System.Windows.Forms.NumericUpDown();
            this.numeric5 = new System.Windows.Forms.NumericUpDown();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.cheburger = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.numeri4 = new System.Windows.Forms.NumericUpDown();
            this.numeri3 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.labe2 = new System.Windows.Forms.Label();
            this.labe5 = new System.Windows.Forms.Label();
            this.labe4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.chepizza = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.numeric8 = new System.Windows.Forms.NumericUpDown();
            this.numeri7 = new System.Windows.Forms.NumericUpDown();
            this.numeri6 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chesand = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.numeric9 = new System.Windows.Forms.NumericUpDown();
            this.numeri5 = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chedes = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.numeric11 = new System.Windows.Forms.NumericUpDown();
            this.numeric0 = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeri12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric6)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeri2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric5)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeri4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeri3)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeri7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeri6)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeri5)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric0)).BeginInit();
            this.SuspendLayout();
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(1499, 83);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(17, 744);
            this.vScrollBar1.TabIndex = 9;
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Size = new System.Drawing.Size(125, 73);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 45;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            this.printPreviewDialog1.Load += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.print);
            this.panel1.Controls.Add(this.toolStrip1);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Location = new System.Drawing.Point(985, 52);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(404, 402);
            this.panel1.TabIndex = 70;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // print
            // 
            this.print.Location = new System.Drawing.Point(0, 34);
            this.print.Name = "print";
            this.print.ReadOnly = true;
            this.print.Size = new System.Drawing.Size(404, 363);
            this.print.TabIndex = 6;
            this.print.Text = "";
            this.print.TextChanged += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newtoolStripButton,
            this.savetoolStripButton,
            this.cutetoolStripButton,
            this.pastetoolStripButton,
            this.printtoolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(404, 31);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // newtoolStripButton
            // 
            this.newtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newtoolStripButton.Image = global::WindowsFormsApplication2.Properties.Resources.open_menu;
            this.newtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newtoolStripButton.Name = "newtoolStripButton";
            this.newtoolStripButton.Size = new System.Drawing.Size(28, 28);
            this.newtoolStripButton.Text = "toolStripButton1";
            this.newtoolStripButton.Click += new System.EventHandler(this.newToolStripButton_Click);
            // 
            // savetoolStripButton
            // 
            this.savetoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.savetoolStripButton.Image = global::WindowsFormsApplication2.Properties.Resources.save;
            this.savetoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.savetoolStripButton.Name = "savetoolStripButton";
            this.savetoolStripButton.Size = new System.Drawing.Size(28, 28);
            this.savetoolStripButton.Text = "toolStripButton2";
            this.savetoolStripButton.Click += new System.EventHandler(this.saveToolStripButton_Click);
            // 
            // cutetoolStripButton
            // 
            this.cutetoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cutetoolStripButton.Image = global::WindowsFormsApplication2.Properties.Resources.barber;
            this.cutetoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutetoolStripButton.Name = "cutetoolStripButton";
            this.cutetoolStripButton.Size = new System.Drawing.Size(28, 28);
            this.cutetoolStripButton.Text = "toolStripButton5";
            this.cutetoolStripButton.Click += new System.EventHandler(this.cutToolStripButton_Click);
            // 
            // pastetoolStripButton
            // 
            this.pastetoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pastetoolStripButton.Image = global::WindowsFormsApplication2.Properties.Resources.paste;
            this.pastetoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pastetoolStripButton.Name = "pastetoolStripButton";
            this.pastetoolStripButton.Size = new System.Drawing.Size(28, 28);
            this.pastetoolStripButton.Text = "toolStripButton6";
            this.pastetoolStripButton.Click += new System.EventHandler(this.copyToolStripButton_Click);
            // 
            // printtoolStripButton
            // 
            this.printtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.printtoolStripButton.Image = global::WindowsFormsApplication2.Properties.Resources.print;
            this.printtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printtoolStripButton.Name = "printtoolStripButton";
            this.printtoolStripButton.Size = new System.Drawing.Size(28, 28);
            this.printtoolStripButton.Text = "toolStripButton3";
            this.printtoolStripButton.Click += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Controls.Add(this.checkBox11);
            this.groupBox1.Controls.Add(this.checkBox12);
            this.groupBox1.Controls.Add(this.checkBox13);
            this.groupBox1.Controls.Add(this.checkBox14);
            this.groupBox1.Controls.Add(this.chedr);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.numeric14);
            this.groupBox1.Controls.Add(this.numeric13);
            this.groupBox1.Controls.Add(this.numeri12);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.labe7);
            this.groupBox1.Controls.Add(this.numeric7);
            this.groupBox1.Controls.Add(this.labe6);
            this.groupBox1.Controls.Add(this.numeric6);
            this.groupBox1.Location = new System.Drawing.Point(359, 368);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(335, 203);
            this.groupBox1.TabIndex = 71;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox11.ForeColor = System.Drawing.Color.Gold;
            this.checkBox11.Location = new System.Drawing.Point(8, 74);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(57, 26);
            this.checkBox11.TabIndex = 108;
            this.checkBox11.Text = "Tea";
            this.checkBox11.UseVisualStyleBackColor = true;
            this.checkBox11.CheckedChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox12.ForeColor = System.Drawing.Color.Gold;
            this.checkBox12.Location = new System.Drawing.Point(10, 106);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(81, 26);
            this.checkBox12.TabIndex = 109;
            this.checkBox12.Text = "Coffee";
            this.checkBox12.UseVisualStyleBackColor = true;
            this.checkBox12.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox13.ForeColor = System.Drawing.Color.Gold;
            this.checkBox13.Location = new System.Drawing.Point(10, 140);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(124, 26);
            this.checkBox13.TabIndex = 110;
            this.checkBox13.Text = "Cold Coffee";
            this.checkBox13.UseVisualStyleBackColor = true;
            this.checkBox13.CheckedChanged += new System.EventHandler(this.checkBox13_CheckedChanged);
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox14.ForeColor = System.Drawing.Color.Gold;
            this.checkBox14.Location = new System.Drawing.Point(9, 171);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(107, 26);
            this.checkBox14.TabIndex = 111;
            this.checkBox14.Text = "Milk shak";
            this.checkBox14.UseVisualStyleBackColor = true;
            this.checkBox14.CheckedChanged += new System.EventHandler(this.checkBox14_CheckedChanged);
            // 
            // chedr
            // 
            this.chedr.AutoSize = true;
            this.chedr.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chedr.ForeColor = System.Drawing.Color.Gold;
            this.chedr.Location = new System.Drawing.Point(9, 42);
            this.chedr.Name = "chedr";
            this.chedr.Size = new System.Drawing.Size(108, 26);
            this.chedr.TabIndex = 108;
            this.chedr.Text = "Coca-cola";
            this.chedr.UseVisualStyleBackColor = true;
            this.chedr.CheckedChanged += new System.EventHandler(this.chedr_CheckedChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label27.Location = new System.Drawing.Point(251, 171);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(69, 22);
            this.label27.TabIndex = 116;
            this.label27.Text = "label19";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label26.Location = new System.Drawing.Point(251, 139);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(69, 22);
            this.label26.TabIndex = 115;
            this.label26.Text = "label19";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label25.Location = new System.Drawing.Point(251, 109);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(69, 22);
            this.label25.TabIndex = 114;
            this.label25.Text = "label19";
            // 
            // numeric14
            // 
            this.numeric14.AccessibleName = "count";
            this.numeric14.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric14.AllowDrop = true;
            this.numeric14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric14.Location = new System.Drawing.Point(175, 110);
            this.numeric14.Name = "numeric14";
            this.numeric14.Size = new System.Drawing.Size(51, 27);
            this.numeric14.TabIndex = 113;
            this.numeric14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric14.ValueChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            this.numeric14.VisibleChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // numeric13
            // 
            this.numeric13.AccessibleName = "count";
            this.numeric13.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric13.AllowDrop = true;
            this.numeric13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric13.Location = new System.Drawing.Point(175, 171);
            this.numeric13.Name = "numeric13";
            this.numeric13.Size = new System.Drawing.Size(51, 27);
            this.numeric13.TabIndex = 112;
            this.numeric13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric13.ValueChanged += new System.EventHandler(this.checkBox14_CheckedChanged);
            this.numeric13.VisibleChanged += new System.EventHandler(this.checkBox14_CheckedChanged);
            // 
            // numeri12
            // 
            this.numeri12.AccessibleName = "count";
            this.numeri12.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeri12.AllowDrop = true;
            this.numeri12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeri12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeri12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeri12.Location = new System.Drawing.Point(175, 139);
            this.numeri12.Name = "numeri12";
            this.numeri12.Size = new System.Drawing.Size(51, 27);
            this.numeri12.TabIndex = 111;
            this.numeri12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeri12.ValueChanged += new System.EventHandler(this.checkBox13_CheckedChanged);
            this.numeri12.VisibleChanged += new System.EventHandler(this.checkBox13_CheckedChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label24.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Snow;
            this.label24.Location = new System.Drawing.Point(118, 15);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(73, 26);
            this.label24.TabIndex = 107;
            this.label24.Text = "Drinks";
            // 
            // labe7
            // 
            this.labe7.AutoSize = true;
            this.labe7.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labe7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labe7.Location = new System.Drawing.Point(251, 74);
            this.labe7.Name = "labe7";
            this.labe7.Size = new System.Drawing.Size(69, 22);
            this.labe7.TabIndex = 6;
            this.labe7.Text = "label19";
            // 
            // numeric7
            // 
            this.numeric7.AccessibleName = "count";
            this.numeric7.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric7.AllowDrop = true;
            this.numeric7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric7.Location = new System.Drawing.Point(175, 75);
            this.numeric7.Name = "numeric7";
            this.numeric7.Size = new System.Drawing.Size(51, 27);
            this.numeric7.TabIndex = 87;
            this.numeric7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric7.ValueChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            this.numeric7.VisibleChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // labe6
            // 
            this.labe6.AutoSize = true;
            this.labe6.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labe6.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labe6.Location = new System.Drawing.Point(251, 41);
            this.labe6.Name = "labe6";
            this.labe6.Size = new System.Drawing.Size(69, 22);
            this.labe6.TabIndex = 5;
            this.labe6.Text = "label18";
            // 
            // numeric6
            // 
            this.numeric6.AccessibleName = "count";
            this.numeric6.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric6.AllowDrop = true;
            this.numeric6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric6.Location = new System.Drawing.Point(175, 43);
            this.numeric6.Name = "numeric6";
            this.numeric6.Size = new System.Drawing.Size(51, 27);
            this.numeric6.TabIndex = 86;
            this.numeric6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric6.ValueChanged += new System.EventHandler(this.chedr_CheckedChanged);
            this.numeric6.VisibleChanged += new System.EventHandler(this.chedr_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.checkBox1);
            this.groupBox5.Controls.Add(this.chefries);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.numeri2);
            this.groupBox5.Controls.Add(this.numeric1);
            this.groupBox5.Controls.Add(this.labe1);
            this.groupBox5.Location = new System.Drawing.Point(12, 51);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(342, 155);
            this.groupBox5.TabIndex = 75;
            this.groupBox5.TabStop = false;
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.Color.Gold;
            this.checkBox1.Location = new System.Drawing.Point(8, 108);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(111, 26);
            this.checkBox1.TabIndex = 93;
            this.checkBox1.Text = "France Fry";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // chefries
            // 
            this.chefries.AutoSize = true;
            this.chefries.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chefries.ForeColor = System.Drawing.Color.Gold;
            this.chefries.Location = new System.Drawing.Point(8, 69);
            this.chefries.Name = "chefries";
            this.chefries.Size = new System.Drawing.Size(143, 26);
            this.chefries.TabIndex = 92;
            this.chefries.Text = "Fried Chicken ";
            this.chefries.UseVisualStyleBackColor = true;
            this.chefries.CheckedChanged += new System.EventHandler(this.chefries_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(104, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 26);
            this.label6.TabIndex = 92;
            this.label6.Text = "Fried Items";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label4.Location = new System.Drawing.Point(261, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 22);
            this.label4.TabIndex = 90;
            this.label4.Text = "label3";
            this.label4.TextChanged += new System.EventHandler(this.numeric2_ValueChanged);
            this.label4.Click += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // numeri2
            // 
            this.numeri2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeri2.Location = new System.Drawing.Point(187, 109);
            this.numeri2.Name = "numeri2";
            this.numeri2.Size = new System.Drawing.Size(51, 27);
            this.numeri2.TabIndex = 89;
            this.numeri2.ValueChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            this.numeri2.VisibleChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            this.numeri2.Click += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // numeric1
            // 
            this.numeric1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric1.Location = new System.Drawing.Point(187, 66);
            this.numeric1.Name = "numeric1";
            this.numeric1.Size = new System.Drawing.Size(51, 27);
            this.numeric1.TabIndex = 88;
            this.numeric1.ValueChanged += new System.EventHandler(this.chefries_CheckedChanged);
            this.numeric1.VisibleChanged += new System.EventHandler(this.chefries_CheckedChanged);
            // 
            // labe1
            // 
            this.labe1.AutoSize = true;
            this.labe1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labe1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labe1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labe1.Location = new System.Drawing.Point(261, 73);
            this.labe1.Name = "labe1";
            this.labe1.Size = new System.Drawing.Size(59, 22);
            this.labe1.TabIndex = 0;
            this.labe1.Text = "label3";
            this.labe1.TextChanged += new System.EventHandler(this.numeric1_ValueChanged);
            this.labe1.Click += new System.EventHandler(this.numeric1_ValueChanged);
            // 
            // numeric2
            // 
            this.numeric2.AccessibleName = "count";
            this.numeric2.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric2.AllowDrop = true;
            this.numeric2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric2.Location = new System.Drawing.Point(187, 50);
            this.numeric2.Name = "numeric2";
            this.numeric2.Size = new System.Drawing.Size(51, 27);
            this.numeric2.TabIndex = 85;
            this.numeric2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric2.ValueChanged += new System.EventHandler(this.cheburger_CheckedChanged);
            this.numeric2.VisibleChanged += new System.EventHandler(this.cheburger_CheckedChanged);
            // 
            // numeric3
            // 
            this.numeric3.AccessibleName = "count";
            this.numeric3.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric3.AllowDrop = true;
            this.numeric3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric3.Location = new System.Drawing.Point(182, 59);
            this.numeric3.Name = "numeric3";
            this.numeric3.Size = new System.Drawing.Size(51, 27);
            this.numeric3.TabIndex = 84;
            this.numeric3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric3.ValueChanged += new System.EventHandler(this.chepizza_CheckedChanged);
            this.numeric3.VisibleChanged += new System.EventHandler(this.chepizza_CheckedChanged);
            // 
            // numeric4
            // 
            this.numeric4.AccessibleName = "count";
            this.numeric4.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric4.AllowDrop = true;
            this.numeric4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric4.Location = new System.Drawing.Point(174, 55);
            this.numeric4.Name = "numeric4";
            this.numeric4.Size = new System.Drawing.Size(51, 27);
            this.numeric4.TabIndex = 83;
            this.numeric4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric4.ValueChanged += new System.EventHandler(this.chesand_CheckedChanged);
            this.numeric4.VisibleChanged += new System.EventHandler(this.chesand_CheckedChanged);
            // 
            // numeric5
            // 
            this.numeric5.AccessibleName = "count";
            this.numeric5.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric5.AllowDrop = true;
            this.numeric5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric5.Location = new System.Drawing.Point(175, 42);
            this.numeric5.Name = "numeric5";
            this.numeric5.Size = new System.Drawing.Size(51, 27);
            this.numeric5.TabIndex = 82;
            this.numeric5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric5.ValueChanged += new System.EventHandler(this.chedes_CheckedChanged);
            this.numeric5.VisibleChanged += new System.EventHandler(this.chedes_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox6.Controls.Add(this.checkBox3);
            this.groupBox6.Controls.Add(this.checkBox2);
            this.groupBox6.Controls.Add(this.cheburger);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.numeri4);
            this.groupBox6.Controls.Add(this.numeri3);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Controls.Add(this.numeric2);
            this.groupBox6.Controls.Add(this.labe2);
            this.groupBox6.Location = new System.Drawing.Point(12, 206);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(342, 171);
            this.groupBox6.TabIndex = 76;
            this.groupBox6.TabStop = false;
            this.groupBox6.Enter += new System.EventHandler(this.groupBox6_Enter);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.ForeColor = System.Drawing.Color.Gold;
            this.checkBox3.Location = new System.Drawing.Point(6, 130);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(145, 26);
            this.checkBox3.TabIndex = 101;
            this.checkBox3.Text = "Cheese Burger";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.ForeColor = System.Drawing.Color.Gold;
            this.checkBox2.Location = new System.Drawing.Point(6, 95);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(152, 26);
            this.checkBox2.TabIndex = 100;
            this.checkBox2.Text = "Chicken Burger";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // cheburger
            // 
            this.cheburger.AutoSize = true;
            this.cheburger.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheburger.ForeColor = System.Drawing.Color.Gold;
            this.cheburger.Location = new System.Drawing.Point(6, 55);
            this.cheburger.Name = "cheburger";
            this.cheburger.Size = new System.Drawing.Size(124, 26);
            this.cheburger.TabIndex = 94;
            this.cheburger.Text = "Beef Burger";
            this.cheburger.UseVisualStyleBackColor = true;
            this.cheburger.CheckedChanged += new System.EventHandler(this.cheburger_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(133, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 26);
            this.label8.TabIndex = 99;
            this.label8.Text = "Burger";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label7.Location = new System.Drawing.Point(261, 130);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 19);
            this.label7.TabIndex = 98;
            this.label7.Text = "label7";
            // 
            // numeri4
            // 
            this.numeri4.AccessibleName = "count";
            this.numeri4.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeri4.AllowDrop = true;
            this.numeri4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeri4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeri4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeri4.Location = new System.Drawing.Point(187, 131);
            this.numeri4.Name = "numeri4";
            this.numeri4.Size = new System.Drawing.Size(51, 27);
            this.numeri4.TabIndex = 96;
            this.numeri4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeri4.ValueChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            this.numeri4.VisibleChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // numeri3
            // 
            this.numeri3.AccessibleName = "count";
            this.numeri3.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeri3.AllowDrop = true;
            this.numeri3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeri3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeri3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeri3.Location = new System.Drawing.Point(187, 94);
            this.numeri3.Name = "numeri3";
            this.numeri3.Size = new System.Drawing.Size(51, 27);
            this.numeri3.TabIndex = 92;
            this.numeri3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeri3.ValueChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            this.numeri3.VisibleChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label5.Location = new System.Drawing.Point(261, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 19);
            this.label5.TabIndex = 91;
            this.label5.Text = "label5";
            // 
            // labe2
            // 
            this.labe2.AutoSize = true;
            this.labe2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labe2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labe2.Location = new System.Drawing.Point(261, 55);
            this.labe2.Name = "labe2";
            this.labe2.Size = new System.Drawing.Size(69, 22);
            this.labe2.TabIndex = 1;
            this.labe2.Text = "label14";
            // 
            // labe5
            // 
            this.labe5.AutoSize = true;
            this.labe5.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labe5.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labe5.Location = new System.Drawing.Point(251, 50);
            this.labe5.Name = "labe5";
            this.labe5.Size = new System.Drawing.Size(69, 22);
            this.labe5.TabIndex = 4;
            this.labe5.Text = "label17";
            // 
            // labe4
            // 
            this.labe4.AutoSize = true;
            this.labe4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labe4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labe4.Location = new System.Drawing.Point(250, 56);
            this.labe4.Name = "labe4";
            this.labe4.Size = new System.Drawing.Size(69, 22);
            this.labe4.TabIndex = 3;
            this.labe4.Text = "label16";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label3.Location = new System.Drawing.Point(261, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "label15";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightBlue;
            this.button2.Location = new System.Drawing.Point(6, 52);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 43);
            this.button2.TabIndex = 77;
            this.button2.Text = "Reset";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightBlue;
            this.button3.Location = new System.Drawing.Point(181, 52);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(81, 43);
            this.button3.TabIndex = 78;
            this.button3.Text = "Total";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.LightBlue;
            this.button5.Location = new System.Drawing.Point(16, 24);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 43);
            this.button5.TabIndex = 80;
            this.button5.Text = "Print";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.FloralWhite;
            this.label14.Location = new System.Drawing.Point(7, 55);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(114, 19);
            this.label14.TabIndex = 81;
            this.label14.Text = "Cost of Drinks";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.FloralWhite;
            this.label15.Location = new System.Drawing.Point(6, 108);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(150, 19);
            this.label15.TabIndex = 82;
            this.label15.Text = "Cost of Food Items";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.FloralWhite;
            this.label16.Location = new System.Drawing.Point(7, 157);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 19);
            this.label16.TabIndex = 83;
            this.label16.Text = "Vat";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.FloralWhite;
            this.label17.Location = new System.Drawing.Point(6, 213);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(80, 19);
            this.label17.TabIndex = 84;
            this.label17.Text = "Sub Total";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.FloralWhite;
            this.label18.Location = new System.Drawing.Point(7, 275);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 19);
            this.label18.TabIndex = 85;
            this.label18.Text = "Total";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.textBox1);
            this.groupBox7.Controls.Add(this.textBox5);
            this.groupBox7.Controls.Add(this.textBox4);
            this.groupBox7.Controls.Add(this.textBox3);
            this.groupBox7.Controls.Add(this.textBox2);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Controls.Add(this.label17);
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Location = new System.Drawing.Point(700, 51);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(279, 331);
            this.groupBox7.TabIndex = 86;
            this.groupBox7.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(162, 47);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(100, 27);
            this.textBox1.TabIndex = 91;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(162, 267);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(100, 27);
            this.textBox5.TabIndex = 90;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.textBox5.VisibleChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(162, 205);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(100, 27);
            this.textBox4.TabIndex = 89;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(162, 149);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(100, 27);
            this.textBox3.TabIndex = 88;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(162, 100);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(100, 27);
            this.textBox2.TabIndex = 87;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.button3);
            this.groupBox8.Controls.Add(this.button2);
            this.groupBox8.Location = new System.Drawing.Point(700, 448);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(279, 110);
            this.groupBox8.TabIndex = 87;
            this.groupBox8.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button7);
            this.groupBox9.Controls.Add(this.button6);
            this.groupBox9.Controls.Add(this.button5);
            this.groupBox9.Location = new System.Drawing.Point(985, 477);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(398, 80);
            this.groupBox9.TabIndex = 88;
            this.groupBox9.TabStop = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.LightBlue;
            this.button7.Location = new System.Drawing.Point(157, 26);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(95, 43);
            this.button7.TabIndex = 82;
            this.button7.Text = "Feedback";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.LightBlue;
            this.button6.Location = new System.Drawing.Point(304, 26);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(88, 43);
            this.button6.TabIndex = 81;
            this.button6.Text = "Exit";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox7);
            this.groupBox2.Controls.Add(this.checkBox6);
            this.groupBox2.Controls.Add(this.checkBox5);
            this.groupBox2.Controls.Add(this.chepizza);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.numeric8);
            this.groupBox2.Controls.Add(this.numeri7);
            this.groupBox2.Controls.Add(this.numeri6);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.numeric3);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(11, 383);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(342, 188);
            this.groupBox2.TabIndex = 89;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox7.ForeColor = System.Drawing.Color.Gold;
            this.checkBox7.Location = new System.Drawing.Point(9, 149);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(119, 26);
            this.checkBox7.TabIndex = 105;
            this.checkBox7.Text = "Plane Pizza";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox6.ForeColor = System.Drawing.Color.Gold;
            this.checkBox6.Location = new System.Drawing.Point(9, 121);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(138, 26);
            this.checkBox6.TabIndex = 104;
            this.checkBox6.Text = "Chicken Pizza";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox5.ForeColor = System.Drawing.Color.Gold;
            this.checkBox5.Location = new System.Drawing.Point(9, 89);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(110, 26);
            this.checkBox5.TabIndex = 103;
            this.checkBox5.Text = "Beef Pizza";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // chepizza
            // 
            this.chepizza.AutoSize = true;
            this.chepizza.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chepizza.ForeColor = System.Drawing.Color.Gold;
            this.chepizza.Location = new System.Drawing.Point(9, 59);
            this.chepizza.Name = "chepizza";
            this.chepizza.Size = new System.Drawing.Size(131, 26);
            this.chepizza.TabIndex = 102;
            this.chepizza.Text = "Cheese Pizza";
            this.chepizza.UseVisualStyleBackColor = true;
            this.chepizza.CheckedChanged += new System.EventHandler(this.chepizza_CheckedChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label12.Location = new System.Drawing.Point(257, 155);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 22);
            this.label12.TabIndex = 101;
            this.label12.Text = "label15";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.Window;
            this.label11.Location = new System.Drawing.Point(133, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 26);
            this.label11.TabIndex = 100;
            this.label11.Text = "Pizza";
            // 
            // numeric8
            // 
            this.numeric8.AccessibleName = "count";
            this.numeric8.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric8.AllowDrop = true;
            this.numeric8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric8.Location = new System.Drawing.Point(182, 155);
            this.numeric8.Name = "numeric8";
            this.numeric8.Size = new System.Drawing.Size(51, 27);
            this.numeric8.TabIndex = 99;
            this.numeric8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric8.ValueChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            this.numeric8.VisibleChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // numeri7
            // 
            this.numeri7.AccessibleName = "count";
            this.numeri7.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeri7.AllowDrop = true;
            this.numeri7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeri7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeri7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeri7.Location = new System.Drawing.Point(182, 122);
            this.numeri7.Name = "numeri7";
            this.numeri7.Size = new System.Drawing.Size(51, 27);
            this.numeri7.TabIndex = 98;
            this.numeri7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeri7.ValueChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            this.numeri7.VisibleChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // numeri6
            // 
            this.numeri6.AccessibleName = "count";
            this.numeri6.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeri6.AllowDrop = true;
            this.numeri6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeri6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeri6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeri6.Location = new System.Drawing.Point(182, 89);
            this.numeri6.Name = "numeri6";
            this.numeri6.Size = new System.Drawing.Size(51, 27);
            this.numeri6.TabIndex = 97;
            this.numeri6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeri6.ValueChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            this.numeri6.VisibleChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label10.Location = new System.Drawing.Point(257, 128);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 19);
            this.label10.TabIndex = 93;
            this.label10.Text = "label10";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label9.Location = new System.Drawing.Point(266, 91);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 19);
            this.label9.TabIndex = 92;
            this.label9.Text = "label9";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.chesand);
            this.groupBox3.Controls.Add(this.checkBox8);
            this.groupBox3.Controls.Add(this.checkBox9);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.numeric9);
            this.groupBox3.Controls.Add(this.numeri5);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.numeric4);
            this.groupBox3.Controls.Add(this.labe4);
            this.groupBox3.Location = new System.Drawing.Point(360, 52);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(334, 154);
            this.groupBox3.TabIndex = 90;
            this.groupBox3.TabStop = false;
            // 
            // chesand
            // 
            this.chesand.AutoSize = true;
            this.chesand.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chesand.ForeColor = System.Drawing.Color.Gold;
            this.chesand.Location = new System.Drawing.Point(7, 56);
            this.chesand.Name = "chesand";
            this.chesand.Size = new System.Drawing.Size(142, 26);
            this.chesand.TabIndex = 103;
            this.chesand.Text = "Sub Sandwich";
            this.chesand.UseVisualStyleBackColor = true;
            this.chesand.CheckedChanged += new System.EventHandler(this.chesand_CheckedChanged);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox8.ForeColor = System.Drawing.Color.Gold;
            this.checkBox8.Location = new System.Drawing.Point(7, 88);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(167, 26);
            this.checkBox8.TabIndex = 104;
            this.checkBox8.Text = "Smoky Sandwich";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox9.ForeColor = System.Drawing.Color.Gold;
            this.checkBox9.Location = new System.Drawing.Point(6, 122);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(167, 26);
            this.checkBox9.TabIndex = 105;
            this.checkBox9.Text = "Cheese Sandwich";
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label20.Location = new System.Drawing.Point(250, 122);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 22);
            this.label20.TabIndex = 99;
            this.label20.Text = "label16";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label19.Location = new System.Drawing.Point(250, 90);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(69, 22);
            this.label19.TabIndex = 98;
            this.label19.Text = "label16";
            // 
            // numeric9
            // 
            this.numeric9.AccessibleName = "count";
            this.numeric9.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric9.AllowDrop = true;
            this.numeric9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric9.Location = new System.Drawing.Point(174, 123);
            this.numeric9.Name = "numeric9";
            this.numeric9.Size = new System.Drawing.Size(51, 27);
            this.numeric9.TabIndex = 97;
            this.numeric9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric9.ValueChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            this.numeric9.VisibleChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // numeri5
            // 
            this.numeri5.AccessibleName = "count";
            this.numeri5.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeri5.AllowDrop = true;
            this.numeri5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeri5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeri5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeri5.Location = new System.Drawing.Point(174, 85);
            this.numeri5.Name = "numeri5";
            this.numeri5.Size = new System.Drawing.Size(51, 27);
            this.numeri5.TabIndex = 96;
            this.numeri5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeri5.ValueChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            this.numeri5.VisibleChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.Window;
            this.label13.Location = new System.Drawing.Point(113, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(103, 26);
            this.label13.TabIndex = 93;
            this.label13.Text = "Sandwich";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.chedes);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.checkBox4);
            this.groupBox4.Controls.Add(this.checkBox10);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.numeric11);
            this.groupBox4.Controls.Add(this.numeric0);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.numeric5);
            this.groupBox4.Controls.Add(this.labe5);
            this.groupBox4.Location = new System.Drawing.Point(359, 206);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(335, 171);
            this.groupBox4.TabIndex = 91;
            this.groupBox4.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 19);
            this.label2.TabIndex = 108;
            this.label2.Text = "label2";
            // 
            // chedes
            // 
            this.chedes.AutoSize = true;
            this.chedes.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chedes.ForeColor = System.Drawing.Color.Gold;
            this.chedes.Location = new System.Drawing.Point(10, 43);
            this.chedes.Name = "chedes";
            this.chedes.Size = new System.Drawing.Size(74, 26);
            this.chedes.TabIndex = 106;
            this.chedes.Text = "Misty";
            this.chedes.UseVisualStyleBackColor = true;
            this.chedes.CheckedChanged += new System.EventHandler(this.chedes_CheckedChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label23.Location = new System.Drawing.Point(251, 115);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(69, 22);
            this.label23.TabIndex = 106;
            this.label23.Text = "label17";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.ForeColor = System.Drawing.Color.Gold;
            this.checkBox4.Location = new System.Drawing.Point(10, 76);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(154, 26);
            this.checkBox4.TabIndex = 106;
            this.checkBox4.Text = "Chocolate Cake";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox10.ForeColor = System.Drawing.Color.Gold;
            this.checkBox10.Location = new System.Drawing.Point(10, 111);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(110, 26);
            this.checkBox10.TabIndex = 107;
            this.checkBox10.Text = "Ice-Cream";
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label22.Location = new System.Drawing.Point(251, 75);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 22);
            this.label22.TabIndex = 105;
            this.label22.Text = "label17";
            // 
            // numeric11
            // 
            this.numeric11.AccessibleName = "count";
            this.numeric11.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric11.AllowDrop = true;
            this.numeric11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric11.Location = new System.Drawing.Point(175, 110);
            this.numeric11.Name = "numeric11";
            this.numeric11.Size = new System.Drawing.Size(51, 27);
            this.numeric11.TabIndex = 104;
            this.numeric11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric11.ValueChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            this.numeric11.VisibleChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // numeric0
            // 
            this.numeric0.AccessibleName = "count";
            this.numeric0.AccessibleRole = System.Windows.Forms.AccessibleRole.List;
            this.numeric0.AllowDrop = true;
            this.numeric0.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numeric0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.numeric0.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.numeric0.Location = new System.Drawing.Point(175, 76);
            this.numeric0.Name = "numeric0";
            this.numeric0.Size = new System.Drawing.Size(51, 27);
            this.numeric0.TabIndex = 103;
            this.numeric0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numeric0.ValueChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            this.numeric0.VisibleChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label21.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.Window;
            this.label21.Location = new System.Drawing.Point(118, 15);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(89, 26);
            this.label21.TabIndex = 100;
            this.label21.Text = "Dessert ";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft YaHei UI", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Gold;
            this.label28.Location = new System.Drawing.Point(630, 9);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(112, 39);
            this.label28.TabIndex = 92;
            this.label28.Text = "MENU";
            // 
            // Table1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1397, 587);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.vScrollBar1);
            this.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Table1";
            this.Tag = "";
            this.Text = "Table 1 menu";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeri12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric6)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeri2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric5)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeri4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeri3)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeri7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeri6)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeri5)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numeric11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric0)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.Label label1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox print;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.NumericUpDown numeric2;
        private System.Windows.Forms.NumericUpDown numeric3;
        private System.Windows.Forms.NumericUpDown numeric4;
        private System.Windows.Forms.NumericUpDown numeric5;
        private System.Windows.Forms.NumericUpDown numeric6;
        private System.Windows.Forms.NumericUpDown numeric7;
        private System.Windows.Forms.NumericUpDown numeric1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label labe7;
        private System.Windows.Forms.Label labe6;
        private System.Windows.Forms.Label labe5;
        private System.Windows.Forms.Label labe4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labe2;
        private System.Windows.Forms.Label labe1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numeri2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numeri4;
        private System.Windows.Forms.NumericUpDown numeri3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown numeric8;
        private System.Windows.Forms.NumericUpDown numeri7;
        private System.Windows.Forms.NumericUpDown numeri6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown numeric14;
        private System.Windows.Forms.NumericUpDown numeric13;
        private System.Windows.Forms.NumericUpDown numeri12;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown numeric9;
        private System.Windows.Forms.NumericUpDown numeri5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown numeric11;
        private System.Windows.Forms.NumericUpDown numeric0;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox chefries;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox cheburger;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox chepizza;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox chesand;
        private System.Windows.Forms.CheckBox chedr;
        private System.Windows.Forms.CheckBox chedes;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.ToolStripButton savetoolStripButton;
        private System.Windows.Forms.ToolStripButton printtoolStripButton;
        private System.Windows.Forms.ToolStripButton cutetoolStripButton;
        private System.Windows.Forms.ToolStripButton pastetoolStripButton;
        private System.Windows.Forms.ToolStripButton newtoolStripButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label28;
    }
}